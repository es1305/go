define({
  "name": "Shopping Platform",
  "version": "0.1.0",
  "description": "Shopping platform",
  "title": "Shopping Platform Description",
  "url": "https://api.shop.com/v1",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2021-03-17T15:03:14.427Z",
    "url": "https://apidocjs.com",
    "version": "0.26.0"
  }
});
